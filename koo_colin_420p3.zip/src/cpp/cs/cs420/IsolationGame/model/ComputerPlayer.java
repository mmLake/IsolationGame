package cpp.cs.cs420.IsolationGame.model;

/**
 * Created by mayalake on 5/17/18.
 */
public class ComputerPlayer {
}
